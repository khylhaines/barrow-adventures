import { PINS } from "./pins.js";

/* =========================================================
   BARROW QUEST QA ENGINE
   ---------------------------------------------------------
   Supports:
   - old core map
   - abbey
   - park
   - kid / teen / adult
   - pin overrides
   - riddle conversion
========================================================= */

function normaliseTier(tier = "kid") {
  return ["kid", "teen", "adult"].includes(tier) ? tier : "kid";
}

function seededIndex(length, salt = 0) {
  if (!length) return 0;
  const n = Math.abs(Number(salt) || 0);
  return n % length;
}

function pickOne(arr, salt = 0) {
  if (!Array.isArray(arr) || !arr.length) return null;
  return arr[seededIndex(arr.length, salt)];
}

function shuffleSeeded(arr, salt = 0) {
  const out = [...arr];
  let seed = Math.abs(Number(salt) || Date.now());

  for (let i = out.length - 1; i > 0; i--) {
    seed = (seed * 9301 + 49297) % 233280;
    const j = Math.floor((seed / 233280) * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function makePromptTask(prompt, mode = "activity") {
  return {
    q: prompt,
    options: ["DONE", "NOT YET", "SKIP", "UNSAFE"],
    answer: 0,
    fact: "",
    meta: { promptOnly: true, mode },
  };
}

function makeFallbackTask(message, meta = {}) {
  return {
    q: message,
    options: ["DONE", "NOT YET", "SKIP", "UNSAFE"],
    answer: 0,
    fact: "",
    meta: { fallback: true, ...meta },
  };
}

/* =========================
   RIDDLE BUILDERS
========================= */

const RIDDLE_FUNNY = {
  kid: [
    "A confused potato in a wizard hat",
    "Your dad’s lost TV remote",
    "A chicken wearing sunglasses",
    "A penguin driving a bus",
  ],
  teen: [
    "Your group chat at 2am",
    "A dramatic pigeon with attitude",
    "A seagull running a business",
    "Your mate after one hour of sleep",
  ],
  adult: [
    "That one drawer full of random cables",
    "Your sat-nav after a wrong turn",
    "A neighbour with strong opinions",
    "The weekly shop before payday",
  ],
};

const RIDDLE_CLOSE = {
  kid: ["A shadow", "A map", "A mirror", "A clock"],
  teen: ["An echo", "A sign", "A picture", "A tool"],
  adult: ["A symbol", "A signal", "A reflection", "A marker"],
};

const RIDDLE_VERY_CLOSE = {
  kid: ["A book", "A bottle", "A road", "A bell"],
  teen: ["A keypad", "A notebook", "A footprint", "A tower"],
  adult: ["A memory", "A pattern", "A route", "A record"],
};

function makeMcqFromRiddle(riddle, tier = "kid", salt = 0) {
  if (!riddle?.q || !riddle?.a) {
    return makeFallbackTask("Broken riddle entry.", { mode: "logic" });
  }

  const correct = riddle.a;
  const funny = pickOne(RIDDLE_FUNNY[tier], salt + 11) || "A confused potato";
  const close = pickOne(RIDDLE_CLOSE[tier], salt + 22) || "A shadow";
  const veryClose = pickOne(RIDDLE_VERY_CLOSE[tier], salt + 33) || "A map";

  let options = [correct, veryClose, close, funny];
  options = [...new Set(options)];

  while (options.length < 4) {
    options.push(`Option ${options.length + 1}`);
  }

  const shuffled = shuffleSeeded(options, salt);
  const answer = shuffled.indexOf(correct);

  return {
    q: riddle.q,
    options: shuffled,
    answer,
    fact: riddle.a,
    meta: { type: "riddle", tier },
  };
}

/* =========================
   QA POOLS BY ZONE
========================= */

export const QA_BY_ZONE = {
  /* =====================================================
     CORE MAP
     -----------------------------------------------------
     This supports your old Barrow map.
     Add your old question pools here later if needed.
  ===================================================== */
  core: {
    quiz: {
      kid: [
        {
          q: "What is Barrow-in-Furness known for building today?",
          options: [
            "Submarines",
            "Chocolate castles",
            "Dragon ships",
            "Flying tractors",
          ],
          answer: 0,
          fact: "Barrow is famous for submarine building.",
        },
      ],
      teen: [
        {
          q: "Which industry helped Barrow grow rapidly in the 1800s?",
          options: [
            "Iron and shipbuilding",
            "Banana farming",
            "Rocket science",
            "Wizard training",
          ],
          answer: 0,
          fact: "Iron and shipbuilding were central to Barrow’s growth.",
        },
      ],
      adult: [
        {
          q: "What transformed Barrow from a small settlement into an industrial town?",
          options: [
            "Iron, docks, and shipbuilding",
            "Gold mining",
            "A royal palace",
            "A giant duck invasion",
          ],
          answer: 0,
          fact: "Barrow grew through industrial development linked to iron and shipbuilding.",
        },
      ],
    },

    history: {
      kid: [
        {
          q: "Was Barrow always a big town?",
          options: [
            "No, it started as a small village",
            "Yes, always huge",
            "It started as a castle",
            "It was built by pirates",
          ],
          answer: 0,
          fact: "Barrow was once a small village before industrial growth.",
        },
      ],
      teen: [
        {
          q: "Why is Barrow important in British industrial history?",
          options: [
            "Shipbuilding and heavy industry",
            "It invented pizza",
            "It was England’s first airport",
            "It trained racing sheep",
          ],
          answer: 0,
          fact: "Barrow played a major role in heavy industry and shipbuilding.",
        },
      ],
      adult: [
        {
          q: "What best describes Barrow’s historic importance?",
          options: [
            "A major industrial and shipbuilding centre",
            "A medieval capital city",
            "A seaside fishing village only",
            "A hidden Roman circus town",
          ],
          answer: 0,
          fact: "Barrow became a major industrial and shipbuilding centre.",
        },
      ],
    },

    logic: {
      kid: [
        { q: "What has keys but can’t open locks?", a: "A piano" },
        { q: "What gets wetter the more it dries?", a: "A towel" },
      ],
      teen: [
        { q: "What disappears when you say its name?", a: "Silence" },
        { q: "What has a ring but no finger?", a: "A phone" },
      ],
      adult: [
        { q: "What belongs to you but others use it more?", a: "Your name" },
        { q: "What is always coming but never arrives?", a: "Tomorrow" },
      ],
    },

    activity: {
      kid: [
        "Point to the oldest-looking thing nearby.",
        "Do an explorer pose for 5 seconds.",
      ],
      teen: ["Give this place a dramatic 3-word title."],
      adult: ["Notice 3 details most people would miss here."],
    },

    family: {
      kid: ["Make a family team pose together."],
      teen: ["Create a 3-word team motto."],
      adult: ["Each person says one word about this place."],
    },

    battle: {
      kid: ["Quick Duel: First to spot something red wins."],
      teen: ["Fast Debate: Best slogan wins."],
      adult: ["Observation Duel: First to name 3 details wins."],
    },

    speed: {
      kid: ["10-Second Scan: Spot a sign, tree, or bench."],
      teen: ["Do 10 silent steps."],
      adult: [
        "30-Second Observation: Name 3 details you'd miss if you rushed.",
      ],
    },

    ghost: {
      kid: [],
      teen: [],
      adult: [],
    },

    boss: {
      kid: [
        {
          q: "What makes Barrow special?",
          options: [
            "Its stories, industry, and landmarks",
            "Only ducks",
            "Only ice cream",
            "A secret moon base",
          ],
          answer: 0,
          fact: "Barrow is special because of its history, places, and industries.",
        },
      ],
      teen: [
        {
          q: "What connects many of Barrow’s landmarks?",
          options: [
            "Industry, memory, and local history",
            "Volcanoes",
            "Tropical jungles",
            "Wizard football",
          ],
          answer: 0,
          fact: "Many Barrow landmarks reflect local industry, memory, and history.",
        },
      ],
      adult: [
        {
          q: "What is the best way to describe Barrow’s heritage?",
          options: [
            "A town shaped by industry, memory, and place",
            "A lost Roman capital",
            "A farming-only village",
            "A floating harbour kingdom",
          ],
          answer: 0,
          fact: "Barrow’s heritage combines industrial history, civic identity, and local memory.",
        },
      ],
    },
  },

  /* =====================================================
     ABBEY
  ===================================================== */
  abbey: {
    quiz: {
      kid: [
        {
          q: "Who lived at Furness Abbey long ago?",
          options: [
            "Knights",
            "Monks",
            "Farmers",
            "A secret army of ninja monks protecting cheese treasure",
          ],
          answer: 1,
          fact: "Cistercian monks lived and prayed at Furness Abbey for centuries.",
        },
        {
          q: "How old is Furness Abbey?",
          options: [
            "About 50 years old",
            "About 200 years old",
            "Over 800 years old",
            "So old the monks probably invented dinosaurs",
          ],
          answer: 2,
          fact: "Furness Abbey was founded in 1123, making it nearly 900 years old.",
        },
        {
          q: "What colour stone is Furness Abbey made from?",
          options: [
            "Red sandstone",
            "White marble",
            "Grey concrete",
            "Sparkly wizard stone mined by magical badgers",
          ],
          answer: 0,
          fact: "The abbey is famous for its deep red sandstone walls.",
        },
      ],
      teen: [
        {
          q: "Why did Furness Abbey become powerful?",
          options: [
            "Iron, land, and farming wealth",
            "It trained dragons",
            "It sold magic soup",
            "It ran England’s first theme park",
          ],
          answer: 0,
          fact: "Furness Abbey became wealthy through land, farming, and control of iron resources.",
        },
        {
          q: "What happened to Furness Abbey in the 1500s?",
          options: [
            "It became a football ground",
            "It was closed during the Dissolution",
            "It was moved stone by stone",
            "It was stolen by pirates",
          ],
          answer: 1,
          fact: "Furness Abbey was dissolved under Henry VIII in 1537.",
        },
      ],
      adult: [
        {
          q: "What major event ended the power of Furness Abbey?",
          options: [
            "The Norman Conquest",
            "The Black Death",
            "The Dissolution of the Monasteries",
            "A sheep rebellion in the valley",
          ],
          answer: 2,
          fact: "The Dissolution under Henry VIII ended the abbey’s power.",
        },
        {
          q: "Why was Furness Abbey one of the richest monasteries in the region?",
          options: [
            "Its control of land, farming, and iron interests",
            "It printed money in the cloister",
            "It rented dragons to the king",
            "It only sold candles and soup",
          ],
          answer: 0,
          fact: "Its wealth came from extensive lands, farming, and links to regional industry.",
        },
      ],
    },

    history: {
      kid: [
        {
          q: "What did monks mostly do at Furness Abbey?",
          options: [
            "Pray and work",
            "Play football",
            "Run a supermarket",
            "Train battle pigeons for medieval sky wars",
          ],
          answer: 0,
          fact: "Monks prayed, farmed, and copied books.",
        },
        {
          q: "What kind of place is Furness Abbey today?",
          options: [
            "A theme park",
            "A ruin and historic site",
            "A shopping centre",
            "A secret underground dragon parking lot",
          ],
          answer: 1,
          fact: "Today Furness Abbey is a protected historic ruin.",
        },
      ],
      teen: [
        {
          q: "Why was the abbey built in a quiet valley?",
          options: [
            "For peace, prayer, and seclusion",
            "For rollercoasters",
            "To hide pirate treasure",
            "Because a monk followed a goat and built a church",
          ],
          answer: 0,
          fact: "Cistercians preferred quiet and remote sites.",
        },
      ],
      adult: [
        {
          q: "What does the scale of the ruins suggest about Furness Abbey?",
          options: [
            "It was minor and poor",
            "It was wealthy and influential",
            "It was temporary",
            "It was secretly built by giants",
          ],
          answer: 1,
          fact: "The scale and architecture reflect major wealth and influence.",
        },
      ],
    },

    logic: {
      kid: [
        { q: "What has keys but can’t open locks?", a: "A piano" },
        { q: "What has hands but can’t clap?", a: "A clock" },
        { q: "What gets wetter the more it dries?", a: "A towel" },
      ],
      teen: [
        { q: "What disappears when you say its name?", a: "Silence" },
        { q: "What has a bed but never sleeps?", a: "A river" },
      ],
      adult: [
        { q: "What belongs to you but others use it more?", a: "Your name" },
        { q: "What is always coming but never arrives?", a: "Tomorrow" },
      ],
    },

    activity: {
      kid: [
        "Walk quietly like a monk for 10 steps.",
        "Stand like a medieval guard for 5 seconds.",
        "Point to the tallest stone you can see.",
      ],
      teen: [
        "Do a 10-second abbey trailer walk.",
        "Create a dramatic ruin pose.",
      ],
      adult: [
        "Pause for 10 seconds and notice 3 details most people miss.",
        "Imagine the abbey fully standing and describe one thing you’d hear.",
      ],
    },

    family: {
      kid: [
        "Create a family abbey guardian pose together.",
        "All whisper quest accepted together.",
      ],
      teen: ["Invent a 3-word team motto for the abbey."],
      adult: ["Each person says one word that fits the abbey atmosphere."],
    },

    battle: {
      kid: ["Balance Duel: Who can stand on one foot longest?"],
      teen: ["Speed Debate: Best 3-word slogan for this place wins."],
      adult: ["Observation Duel: First to name 3 details wins."],
    },

    speed: {
      kid: ["10-Second Scan: Point to the nearest old stone."],
      teen: ["Stealth Meter: 10 silent steps."],
      adult: [
        "30-Second Observation: Name 3 details you'd miss if you rushed.",
      ],
    },

    ghost: {
      kid: [
        "A ghost monk has been spotted. Stand still and listen for 5 seconds.",
      ],
      teen: [
        "Legend says a headless monk still guards the gate. Look toward the arch and report what you notice.",
      ],
      adult: [
        "Local folklore claims monks were heard in the valley long after the abbey fell. Pause and reflect on why legends survive.",
      ],
    },

    boss: {
      kid: [
        {
          q: "Who closed Furness Abbey?",
          options: [
            "King Arthur",
            "King Henry VIII",
            "A pirate king",
            "A biscuit thief in a crown",
          ],
          answer: 1,
          fact: "Henry VIII closed monasteries in the 1500s.",
        },
      ],
      teen: [
        {
          q: "What historical process ended monastic life at Furness Abbey?",
          options: [
            "The Dissolution of the Monasteries",
            "The Roman retreat",
            "The Great Football Ban",
            "An angry wizard tax audit",
          ],
          answer: 0,
          fact: "The Dissolution ended monasteries under Henry VIII.",
        },
      ],
      adult: [
        {
          q: "Why were monasteries like Furness Abbey dissolved?",
          options: [
            "To strengthen royal control and seize wealth",
            "To make room for car parks",
            "Because monks banned bread",
            "Because one sheep became politically dangerous",
          ],
          answer: 0,
          fact: "Royal power and money were central to the Dissolution.",
        },
      ],
    },
  },

  /* =====================================================
     PARK
  ===================================================== */
  park: {
    quiz: {
      kid: [
        {
          q: "What kind of place is Barrow Park for families?",
          options: [
            "A park for play and walks",
            "A submarine factory",
            "A giant castle moat",
            "A secret duck parliament",
          ],
          answer: 0,
          fact: "Barrow Park is a public park for leisure, walking, and family activities.",
        },
        {
          q: "What might you hear near the bandstand?",
          options: [
            "Music",
            "Submarine alarms",
            "Dragon roars",
            "A trumpet-playing squirrel mayor",
          ],
          answer: 0,
          fact: "Bandstands were built for music and public performances.",
        },
        {
          q: "What can you often see around the lake?",
          options: [
            "Birds and ducks",
            "Sharks",
            "Volcanoes",
            "A pirate penguin with a skateboard",
          ],
          answer: 0,
          fact: "The lake area is a good place to spot birds and other wildlife.",
        },
      ],
      teen: [
        {
          q: "Why were parks like Barrow Park important to growing towns?",
          options: [
            "They gave people space for leisure and community life",
            "They hid secret tanks underground",
            "They replaced all roads",
            "They were built for dragon racing",
          ],
          answer: 0,
          fact: "Victorian parks were designed as public spaces for recreation and civic pride.",
        },
        {
          q: "What does a bandstand suggest about the park’s past?",
          options: [
            "Music, gatherings, and public events",
            "Military submarine testing",
            "Airport departures",
            "A secret disco for pigeons",
          ],
          answer: 0,
          fact: "Bandstands were often the centre of performances and festivals in public parks.",
        },
      ],
      adult: [
        {
          q: "What was one major purpose of Victorian public parks?",
          options: [
            "To improve public recreation and civic life",
            "To store heavy machinery",
            "To replace schools",
            "To host formal duck elections",
          ],
          answer: 0,
          fact: "Victorian parks reflected public health, leisure, and civic ambition.",
        },
        {
          q: "What does Barrow Park’s mix of leisure spaces suggest?",
          options: [
            "A designed public landscape for varied recreation",
            "A military training base",
            "An abandoned estate",
            "A plot created by highly organised geese",
          ],
          answer: 0,
          fact: "Features like gardens, lake, sports areas, and bandstands show planned public recreation.",
        },
      ],
    },

    history: {
      kid: [
        {
          q: "What does the cenotaph help people remember?",
          options: [
            "War heroes",
            "Ice cream flavours",
            "Football boots",
            "A lost army of giant hamsters",
          ],
          answer: 0,
          fact: "The cenotaph is a memorial to people lost in war.",
        },
        {
          q: "Why were bandstands built in parks?",
          options: [
            "For music and events",
            "For spaceship launches",
            "For keeping dragons warm",
            "For dancing parrots only",
          ],
          answer: 0,
          fact: "Bandstands were used for concerts and public entertainment.",
        },
      ],
      teen: [
        {
          q: "Why do memorials matter in public parks?",
          options: [
            "They connect daily life with remembrance",
            "They make grass grow faster",
            "They stop rain",
            "They were built for invisible choirs",
          ],
          answer: 0,
          fact: "Memorials in public spaces help communities remember shared history.",
        },
      ],
      adult: [
        {
          q: "What does the cenotaph add to the meaning of the park?",
          options: [
            "A place of civic memory within leisure space",
            "A hidden transport hub",
            "A former castle keep",
            "A monument to extremely competitive ducks",
          ],
          answer: 0,
          fact: "Public parks often combine recreation with remembrance and civic identity.",
        },
      ],
    },

    logic: {
      kid: [
        { q: "What has keys but can’t open locks?", a: "A piano" },
        { q: "What gets wetter the more it dries?", a: "A towel" },
      ],
      teen: [
        { q: "What disappears when you say its name?", a: "Silence" },
        { q: "What has a ring but no finger?", a: "A phone" },
      ],
      adult: [
        { q: "What has branches but no leaves?", a: "A bank" },
        { q: "What is always coming but never arrives?", a: "Tomorrow" },
      ],
    },

    activity: {
      kid: [
        "Do a pirate pose near the play area.",
        "Balance for 5 seconds like a park champion.",
        "Point to something green as fast as you can.",
      ],
      teen: [
        "Do a 10-second main-character walk across the park.",
        "Create a dramatic team pose for this location.",
      ],
      adult: [
        "Notice 3 details in this area that most people would miss.",
        "Choose whether this part of the park feels lively, calm, or mysterious.",
      ],
    },

    family: {
      kid: [
        "Make a family festival pose together.",
        "All point to the most interesting thing nearby.",
      ],
      teen: ["Invent a 3-word park team motto."],
      adult: ["Each person says one word that matches this part of the park."],
    },

    battle: {
      kid: ["Quick Duel: First to spot something blue wins."],
      teen: ["Fast Debate: Best slogan for this place wins."],
      adult: ["Observation Duel: First to name 3 details wins."],
    },

    speed: {
      kid: ["10-Second Scan: Spot a tree, bench, or sign."],
      teen: ["Stealth Walk: 10 silent steps."],
      adult: [
        "30-Second Observation: Name 3 details you'd miss if you rushed.",
      ],
    },

    ghost: {
      kid: [],
      teen: [],
      adult: [],
    },

    boss: {
      kid: [
        {
          q: "Festival Boss: What kind of place is the bandstand for?",
          options: [
            "Music and events",
            "Submarine parking",
            "Rocket launches",
            "Secret hamster concerts",
          ],
          answer: 0,
          fact: "Bandstands were built for music and public performances.",
        },
        {
          q: "Memory Keeper: What does the cenotaph remember?",
          options: [
            "War heroes",
            "Lost footballs",
            "Ice cream vans",
            "A duck who became king",
          ],
          answer: 0,
          fact: "The cenotaph is a place of remembrance.",
        },
        {
          q: "Park Champion: What do you need for a challenge boss?",
          options: [
            "Speed, balance, and focus",
            "A dragon",
            "A tractor",
            "A sandwich made of lightning",
          ],
          answer: 0,
          fact: "Challenge routes test movement and quick thinking.",
        },
      ],
      teen: [
        {
          q: "Festival Revival: What was the bandstand originally for?",
          options: [
            "Public performances and gatherings",
            "Aircraft repair",
            "Underground tunnel meetings",
            "Training elite pigeons",
          ],
          answer: 0,
          fact: "Bandstands often hosted music and community events.",
        },
        {
          q: "Mudman Mystery: Why do strange landmarks create stories?",
          options: [
            "Because unusual places invite imagination",
            "Because statues write newspapers",
            "Because benches create weather",
            "Because squirrels hide all the facts",
          ],
          answer: 0,
          fact: "People often create stories and legends around unusual landmarks.",
        },
      ],
      adult: [
        {
          q: "Memory Keeper: What role does remembrance play in a public park?",
          options: [
            "It links everyday life with civic memory",
            "It turns the park into a harbour",
            "It replaces recreation",
            "It was invented by argumentative geese",
          ],
          answer: 0,
          fact: "Memorials in public spaces connect daily life and shared history.",
        },
        {
          q: "Festival Revival: What does the bandstand symbolise in a park like this?",
          options: [
            "Community gathering and civic culture",
            "Industrial secrecy",
            "Military command",
            "An elite duck orchestra headquarters",
          ],
          answer: 0,
          fact: "Bandstands symbolise shared public culture and leisure.",
        },
      ],
    },
  },
};

/* =========================
   PIN OVERRIDES
========================= */

export const QA_PIN_OVERRIDES = {
  abbey_boss: {
    boss: {
      kid: [
        {
          q: "Final Abbey Trial: Who lived here long ago?",
          options: [
            "Monks",
            "Aliens",
            "Pirates",
            "A secret gang of time-travelling cheese wizards",
          ],
          answer: 0,
          fact: "Monks lived at Furness Abbey for centuries.",
        },
      ],
      teen: [],
      adult: [],
    },
  },

  abbey_headless_monk: {
    ghost: {
      kid: [
        "Legend alert: The Headless Monk has appeared at the gate. Look carefully and stay brave.",
      ],
      teen: [
        "Ghost Stage: The Headless Monk legend is active. Scan the gate and decide if this is myth, fear, or memory.",
      ],
      adult: [
        "Folklore Event: The Headless Monk is said to guard the entrance. Consider why ruins attract stories of unfinished souls.",
      ],
    },
  },

  park_boss_bandstand: {
    boss: {
      kid: [
        {
          q: "Festival Revival: What belongs at a bandstand?",
          options: [
            "Music and crowds",
            "Submarines",
            "Volcanoes",
            "A trumpet-playing penguin king",
          ],
          answer: 0,
          fact: "Bandstands were made for music and public events.",
        },
      ],
      teen: [],
      adult: [],
    },
  },

  park_boss_cenotaph: {
    boss: {
      kid: [
        {
          q: "Memory Keeper: What does the cenotaph help us do?",
          options: [
            "Remember people",
            "Launch rockets",
            "Find treasure",
            "Train ninja ducks",
          ],
          answer: 0,
          fact: "The cenotaph is a place of remembrance.",
        },
      ],
      teen: [],
      adult: [],
    },
  },

  park_boss_mudman: {
    boss: {
      kid: [
        {
          q: "Mudman Mystery: Why do strange places feel mysterious?",
          options: [
            "Because they make us imagine stories",
            "Because they are made of cheese",
            "Because statues run the park at night",
            "Because pigeons hide all the clues",
          ],
          answer: 0,
          fact: "Mysterious places often inspire stories and legends.",
        },
      ],
      teen: [],
      adult: [],
    },
  },

  park_boss_skate: {
    boss: {
      kid: [
        {
          q: "Park Champion: What helps in a challenge zone?",
          options: [
            "Energy and balance",
            "A dragon saddle",
            "A submarine pass",
            "A thunder sandwich",
          ],
          answer: 0,
          fact: "Challenge zones reward movement, balance, and confidence.",
        },
      ],
      teen: [],
      adult: [],
    },
  },
};

/* =========================
   HELPERS
========================= */

function getPinById(pinId) {
  if (!pinId || !Array.isArray(PINS)) return null;
  return PINS.find((p) => p.id === pinId) || null;
}

function resolvePool({ pinId, zone, mode, tier }) {
  const pinOverride = QA_PIN_OVERRIDES?.[pinId]?.[mode]?.[tier];
  if (Array.isArray(pinOverride) && pinOverride.length) {
    return { pool: pinOverride, source: "pin" };
  }

  const zonePool = QA_BY_ZONE?.[zone]?.[mode]?.[tier];
  if (Array.isArray(zonePool) && zonePool.length) {
    return { pool: zonePool, source: "zone" };
  }

  const zoneKid = QA_BY_ZONE?.[zone]?.[mode]?.kid;
  if (Array.isArray(zoneKid) && zoneKid.length) {
    return { pool: zoneKid, source: "zone-kid-fallback" };
  }

  return { pool: [], source: "none" };
}

/* =========================
   MAIN EXPORT
========================= */

export function getQA(input = {}) {
  const pinId = input.pinId || null;
  const pin = getPinById(pinId);

  const zone =
    input.zone || pin?.zone || (pin?.set === "core" ? "core" : "core");

  const mode = input.mode || "quiz";
  const tier = normaliseTier(input.tier || "kid");
  const salt = input.salt || Date.now();

  const { pool, source } = resolvePool({ pinId, zone, mode, tier });

  if (!pool.length) {
    return makeFallbackTask(`No ${mode} content found for ${zone} (${tier}).`, {
      zone,
      mode,
      tier,
      source,
    });
  }

  const picked = pickOne(pool, salt);

  if (mode === "logic" && picked?.q && picked?.a) {
    const built = makeMcqFromRiddle(picked, tier, salt);
    built.meta = { ...(built.meta || {}), zone, pinId, source, mode, tier };
    return built;
  }

  if (picked?.q && Array.isArray(picked?.options)) {
    return {
      ...picked,
      meta: {
        ...(picked.meta || {}),
        zone,
        pinId,
        source,
        mode,
        tier,
      },
    };
  }

  if (typeof picked === "string") {
    return {
      ...makePromptTask(picked, mode),
      meta: {
        zone,
        pinId,
        source,
        mode,
        tier,
        promptOnly: true,
      },
    };
  }

  return makeFallbackTask("Task format not recognised.", {
    zone,
    pinId,
    source,
    mode,
    tier,
  });
}
